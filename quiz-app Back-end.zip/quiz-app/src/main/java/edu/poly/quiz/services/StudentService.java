package edu.poly.quiz.services;

import java.util.Optional;

import edu.poly.quiz.domains.Student;

public interface StudentService {

	void deleteAll();

	void deleteAll(Iterable<? extends Student> entities);

	void delete(Student entity);

	void deleteById(String id);

	long count();

	Iterable<Student> findAllById(Iterable<String> ids);

	Iterable<Student> findAll();

	boolean existsById(String id);

	Optional<Student> findById(String id);

	<S extends Student> Iterable<S> saveAll(Iterable<S> entities);

	<S extends Student> S save(S entity);

	

	
	
}
