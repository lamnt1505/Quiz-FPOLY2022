package edu.poly.quiz.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import edu.poly.quiz.domains.Question;
import edu.poly.quiz.domains.Subject;

@Repository
public interface QuestionRepository extends CrudRepository<Question,Long> {
	List<Question> findQuestionsBySubject(Subject subjectId);					
}
