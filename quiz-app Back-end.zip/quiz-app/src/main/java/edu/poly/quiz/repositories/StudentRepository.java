package edu.poly.quiz.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import edu.poly.quiz.domains.Student;

@Repository
public interface StudentRepository extends CrudRepository<Student,String> {
	
}
