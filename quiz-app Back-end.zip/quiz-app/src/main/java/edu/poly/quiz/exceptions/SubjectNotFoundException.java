package edu.poly.quiz.exceptions;

public class SubjectNotFoundException extends RuntimeException {
	public SubjectNotFoundException() {
		super("Subject Not Found Exception");
	}
}
