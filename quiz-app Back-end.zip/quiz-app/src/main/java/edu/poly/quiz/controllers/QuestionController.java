package edu.poly.quiz.controllers;



import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.poly.quiz.domains.Question;
import edu.poly.quiz.domains.Subject;
import edu.poly.quiz.exceptions.QuestionNotFoundException;
import edu.poly.quiz.services.QuestionService;

@RestController
@RequestMapping("questions")
public class QuestionController {
	
	private QuestionService questionService;
	
	public QuestionController(QuestionService questionService) {
		this.questionService = questionService;
	}
	@GetMapping("/{id}/get")
	public Question get(@PathVariable Long id) {
		Question question = questionService.findById(id)
				.orElseThrow(()-> new QuestionNotFoundException());
		
		return question;
	}
	@GetMapping("/{subjectId}/findBySubject")
	public List<Question> findAllBySubject(@PathVariable ("subjectId")String subjectId){
		return questionService.findQuestionsBySubjectId(subjectId);
	}
	@GetMapping("")
	public List<Question> findAll(){
		return (List<Question>) questionService.findAll();
	}
	
	@PostMapping("")
	public Question insert(@RequestBody Question question) {
		return questionService.save(question);
	}
	@PostMapping("/{subjectId}/insert")
	public List<Question> insert(@PathVariable("subjectId") String subjectId,@RequestBody List<Question> questions) {
		questions.forEach(question->{
			Subject sub = new Subject();
			
			sub.setId(subjectId);
			question.setSubject(sub);
			Question q = questionService.save(question);
			question.setAnswers(q.getAnswers());
			
		});
		return questions;
	}
	@PutMapping("/{id}/update")
	public Question update(@PathVariable ("id") Long id, @RequestBody Question question) {
		return questionService.findById(id)
				.map(q ->{
					questionService.deleteAnswersByQuestionId(id);
					
					BeanUtils.copyProperties(question, q);
					
					question.getAnswers().forEach(answer ->{
						answer.setQuestion(q);
					});
					return questionService.save(q);
				}).get();
	}
	
	@DeleteMapping("/{id}/delete")
	public ResponseEntity<Void> deleteQuestion(Long id){
		questionService.deleteById(id);
		
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}
