package edu.poly.quiz.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.poly.quiz.domains.Student;
import edu.poly.quiz.repositories.StudentRepository;


@Service 
public class StudentServicelmpl implements StudentService {
	@Autowired
	private StudentRepository studentRepository;

	@Override
	public <S extends Student> S save(S entity) {
		return studentRepository.save(entity);
	}

	@Override
	public <S extends Student> Iterable<S> saveAll(Iterable<S> entities) {
		return studentRepository.saveAll(entities);
	}

	@Override
	public Optional<Student> findById(String id) {
		return studentRepository.findById(id);
	}

	@Override
	public boolean existsById(String id) {
		return studentRepository.existsById(id);
	}

	@Override
	public Iterable<Student> findAll() {
		return studentRepository.findAll();
	}

	@Override
	public Iterable<Student> findAllById(Iterable<String> ids) {
		return studentRepository.findAllById(ids);
	}

	@Override
	public long count() {
		return studentRepository.count();
	}

	@Override
	public void deleteById(String id) {
		studentRepository.deleteById(id);
	}

	@Override
	public void delete(Student entity) {
		studentRepository.delete(entity);
	}

	@Override
	public void deleteAll(Iterable<? extends Student> entities) {
		studentRepository.deleteAll(entities);
	}

	@Override
	public void deleteAll() {
		studentRepository.deleteAll();
	}
	
	
}
