package edu.poly.quiz.domains;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.GeneratedValue;
import javax.persistence.Column;
import javax.validation.constraints.NotNull;



@Entity
@Table(name = "subjects")
public class Subject {
	@Id
	private String id;
	
	@Column(columnDefinition = "nvarchar(50)")
	@NotNull
	private String name;
	@Column(length = 100)
	@NotNull
	
	private String logo;
	
	@OneToMany(mappedBy = "subject")
	private Set<Question> questions = new HashSet<>(); 
	
	
	
	public Set<Question> getQuestions() {
		return questions;
	}
	public void setQuestions(Set<Question> questions) {
		this.questions = questions;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	
}
