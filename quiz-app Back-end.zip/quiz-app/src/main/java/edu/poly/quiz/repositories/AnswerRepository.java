package edu.poly.quiz.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import edu.poly.quiz.domains.Answer;

@Repository
public interface AnswerRepository extends CrudRepository<Answer, Long> {
	void deleteAnswersByQuestion_Id(Long questionId);
}
