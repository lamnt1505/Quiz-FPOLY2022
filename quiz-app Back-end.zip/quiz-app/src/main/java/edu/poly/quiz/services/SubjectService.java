package edu.poly.quiz.services;

import java.util.Optional;

import edu.poly.quiz.domains.Subject;

public interface SubjectService  {

	void deleteAll();

	void deleteAll(Iterable<Subject> entities);

	void deleteAllById(Iterable<? extends Long> ids);

	void delete(Subject entity);

	void deleteById(Long id);

	long count();

	Iterable<Subject> findAllById(Iterable<Long> ids);

	Iterable<Subject> findAll();

	boolean existsById(Long id);

	Optional<Subject> findById(Long id);

	Iterable<Subject> saveAll(Iterable<Subject> entities);

	Subject save(Subject entity);
	
}
