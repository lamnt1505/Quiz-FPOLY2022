package edu.poly.quiz.exceptions;

public class StudentNotFoundException extends RuntimeException {
	public StudentNotFoundException() {
		super("Student Not Found Exception");
	}
}
