package edu.poly.quiz.exceptions;

public class QuestionNotFoundException extends RuntimeException {
	public QuestionNotFoundException() {
		super("Question Not Found Exception");
	}
}
