package edu.poly.quiz.controllers;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.poly.quiz.domains.Student;
import edu.poly.quiz.dtos.LoginDto;
import edu.poly.quiz.exceptions.StudentNotFoundException;
import edu.poly.quiz.services.StudentService;


@RestController
@RequestMapping("students")
public class StudentController {
	@Autowired
	private StudentService studentService;
	
	@GetMapping("/{id}/get")
	public Student get(@PathVariable ("id")String id) {
		return studentService.findById(id)
				.orElseThrow(()-> new StudentNotFoundException()); 
	}
	@PostMapping("/checkLogin")
	public Student checkLogin(@RequestBody LoginDto login) {
		Student student = studentService.findById(login.getUsername()) 
				.orElseThrow(()->new StudentNotFoundException());
		
		if(student.getPassword().equals(login.getPassword())) {
			student.setPassword("");
			return student;
		}
		
		return null;
	}
	@GetMapping()
	public List<Student> getAll(){
		return (List<Student>) studentService.findAll();
	}
	
	@PostMapping("/insertAll")
	public List<Student> insert(@RequestBody List<Student> students){
		return (List<Student>) studentService.saveAll(students);
	}
	@PostMapping()
	public Student insert(@RequestBody Student student) {
		return studentService.save(student);
	}
	@PutMapping("/{id}/update")
	public Student update(@PathVariable String id, @RequestBody Student student) {
		return studentService.findById(id)
				.map(old ->{
					BeanUtils.copyProperties(student,old);
					
					return studentService.save(old);
				}).get();
	}
	@DeleteMapping("/{id}/delete")
	public ResponseEntity<Void> deleteStudent(@PathVariable("id") String id){
		studentService.deleteById(id);
		
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}
