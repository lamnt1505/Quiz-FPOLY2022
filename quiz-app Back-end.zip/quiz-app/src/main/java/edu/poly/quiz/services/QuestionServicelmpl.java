package edu.poly.quiz.services;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.poly.quiz.domains.Question;
import edu.poly.quiz.domains.Subject;
import edu.poly.quiz.domains.Answer;
import edu.poly.quiz.repositories.AnswerRepository;
import edu.poly.quiz.repositories.QuestionRepository;

@Service 
public class QuestionServicelmpl implements QuestionService {
	@Autowired
	private QuestionRepository questionRepository ;
	@Autowired
	private AnswerRepository answerRepository;
	
	
	@Override
	public void deleteAnswersByQuestionId(Long questionId) {
		answerRepository.deleteAnswersByQuestion_Id(questionId);
	}
	@Override
	public List<Question> findQuestionsBySubjectId(String subjectId) {
		Subject subject = new Subject();
		subject.setId(subjectId);
		System.out.println(subjectId);
		return questionRepository.findQuestionsBySubject(subject);
	}
	@Override
	public <S extends Question> S save(S entity) {
		Set<Answer> list = entity.getAnswers();
		
		entity.setAnswers(null);
		
		S question = questionRepository.save(entity);
		
		if(list != null && list.size()>0) {
			list.forEach(answer ->{
				answer.setQuestion(question);
				
				answer = answerRepository.save(answer);
			});
			question.setAnswers(list);
		}
		
		return question;
	}
	@Override
	public <S extends Question> Iterable<S> saveAll(Iterable<S> entities) {
		return questionRepository.saveAll(entities);
	}
	@Override
	public Optional<Question> findById(Long id) {
		return questionRepository.findById(id);
	}
	@Override
	public boolean existsById(Long id) {
		return questionRepository.existsById(id);
	}
	@Override
	public Iterable<Question> findAll() {
		return questionRepository.findAll();
	}
	@Override
	public Iterable<Question> findAllById(Iterable<Long> ids) {
		return questionRepository.findAllById(ids);
	}
	@Override
	public long count() {
		return questionRepository.count();
	}
	@Override
	public void deleteById(Long id) {
		questionRepository.deleteById(id);
	}
	@Override
	public void delete(Question entity) {
		questionRepository.delete(entity);
	}
	@Override
	public void deleteAll(Iterable<? extends Question> entities) {
		questionRepository.deleteAll(entities);
	}
	@Override
	public void deleteAll() {
		questionRepository.deleteAll();
	}
	
	
}
