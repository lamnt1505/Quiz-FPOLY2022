package edu.poly.quiz.repositories;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;

import edu.poly.quiz.domains.Subject;


@Repository
public interface SubjectRepository extends CrudRepository<Subject,Long> {
	
}
