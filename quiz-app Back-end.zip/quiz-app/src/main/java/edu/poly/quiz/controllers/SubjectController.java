package edu.poly.quiz.controllers;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import edu.poly.quiz.domains.Subject;
import edu.poly.quiz.services.SubjectService;
import edu.poly.quiz.exceptions.SubjectNotFoundException;

@RestController
@RequestMapping("/subjects")
public class SubjectController {
	@Autowired
	private SubjectService subjectService;
	@GetMapping()
	public List<Subject> getAll(){
		return (List<Subject>) subjectService.findAll();
	}
	
	@GetMapping("/{id}/get")
	public Subject get(@PathVariable Long id) {
		Subject subject = subjectService.findById(id)
				.orElseThrow(() -> new SubjectNotFoundException());
		
		return  subject;
	}
	@PostMapping("")
	public Subject insert(@RequestBody Subject subject) {
		return subjectService.save(subject);
	}
	@PostMapping("/insertAll")
	public List<Subject> insert(@RequestBody List<Subject> subject) {
		return (List<Subject>) subjectService.saveAll(subject);
	}
	@PostMapping("/{id}/update")
	public Subject update(@PathVariable Long id, @RequestBody Subject subject) {
		return subjectService.findById(id)
				.map(sub -> {
					sub.setName(subject.getName());
					sub.setLogo(subject.getLogo());
					
					return subjectService.save(sub);
				})
				.get();
	}
}
