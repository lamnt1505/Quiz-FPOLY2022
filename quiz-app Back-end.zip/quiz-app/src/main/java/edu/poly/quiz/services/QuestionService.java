package edu.poly.quiz.services;

import java.util.List;
import java.util.Optional;

import edu.poly.quiz.domains.Question;

public interface QuestionService {

	void deleteAll();

	void deleteAll(Iterable<? extends Question> entities);

	void delete(Question entity);

	void deleteById(Long id);

	long count();

	Iterable<Question> findAllById(Iterable<Long> ids);

	Iterable<Question> findAll();

	boolean existsById(Long id);

	Optional<Question> findById(Long id);

	<S extends Question> Iterable<S> saveAll(Iterable<S> entities);

	<S extends Question> S save(S entity);

	List<Question> findQuestionsBySubjectId(String subjectId);

	void deleteAnswersByQuestionId(Long questionId);

	

	
	
}
